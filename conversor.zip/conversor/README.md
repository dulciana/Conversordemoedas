CONVERSOR DE MOEDAS
Projeto iniciado com participação na Imersão Alura, um evento gratuito.
Tecnologias   |    Projeto   |    Layout   |    Licença

License

🧑‍🚀 A idéia deste projeto foi inspirada no 1° dia da imersão AluraDev apresentado por Paulo Silveira, Rafaella Ballerini e Guilherme Lima.


Esse projeto está sendo desenvolvido com as seguintes tecnologias:

HTML
CSS
JavaScript
Git and GitHub
Consumo de API
💻 Projeto
A intenção é fazer com que o conversor de moedas lhe possibilite acessar on-line a cotação no momento atual e converter o valor desejado consumindo a API da EXCHANGE RATE.🚀

Visite o projeto online

:memo: Licença
Este projeto está sob a licença MIT.


Obrigado por visitar meu Git e se chegou até aqui dê um "Follow" que retribuo, quem sabe não podemos colaborar em algum projeto juntos?

Até a próxima! 😁🖖.